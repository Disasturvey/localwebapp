(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['tomi:upload-jquery'] = {};

})();

//# sourceMappingURL=tomi_upload-jquery.js.map
